<?php 
// Recupera o usuário logado e configurações globais