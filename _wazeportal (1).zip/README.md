# WazeportalBR
 
Projeto desenvolvido com o objetivo de auxiliar concessionárias , prefeituras a acompanhar os dados do Waze for Cities.

Sistema desenvolvido em PHP 8 e Twig

Aberto a apoio de outros colegas da comunidade waze BR

Projeto em desenvolvimento inicial

Aberto a sugestões.

Ainda nao disponível online